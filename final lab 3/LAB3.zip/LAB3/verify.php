<?php

	require "mail.php";
	require "functions.php";
	check_login();

	$errors = array();

	if ($_SERVER['REQUEST_METHOD'] == "GET" && !check_verified()) {

		// send email
		$vars['code'] = rand(10000, 99999);

		// save to database
		$vars['expires'] = (time() + (60 * 10));
		$vars['email'] = $_SESSION['USER']->email;

		$query = "INSERT INTO verify (code, expires, email) VALUES (:code, :expires, :email)";
		database_run($query, $vars);

		$message = "Your code is " . $vars['code'];
		$subject = "Email Verification";
		$recipient = $vars['email'];
		send_mail($recipient, $subject, $message);
	}

	if ($_SERVER['REQUEST_METHOD'] == "POST") {

		if (!check_verified()) {

			$query = "SELECT * FROM verify WHERE code = :code AND email = :email";
			$vars = array();
			$vars['email'] = $_SESSION['USER']->email;
			$vars['code'] = $_POST['code'];

			$row = database_run($query, $vars);

			if (is_array($row)) {
				$row = $row[0];
				$time = time();

				if ($row->expires > $time) {

					$id = $_SESSION['USER']->id;
					$query = "UPDATE users SET email_verified = email WHERE id = '$id' LIMIT 1";
					
					database_run($query);

					header("Location: profile.php");
					die;
				} else {
					$errors[] = "Code expired";
				}

			} else {
				$errors[] = "Wrong code";
			}
		} else {
			$errors[] = "You're already verified";
		}
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Verify</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style>
		/* Custom CSS styles */
		.container-box {
			background: linear-gradient(to bottom right, #87CEEB, #ffffff);
			padding: 20px;
			border-radius: 1rem;
			box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08);
		}
		.btn-container {
			margin-top: 10px;
		}
	</style>
</head>
<body>
	<section class="vh-100 gradient-custom">
		<div class="container py-5 h-100">
			<div class="row d-flex justify-content-center align-items-center h-100">
				<div class="col-12 col-md-8 col-lg-6 col-xl-5">
					<div class="card bg-dark text-white" style="border-radius: 1rem;">
						<div class="card-body p-5 text-center">

							<div class="mb-md-5 mt-md-4 pb-5">
								<h2 class="fw-bold mb-2 text-uppercase">Verify</h2>
								<p class="text-white-50 mb-5">An email was sent to your address. Paste the code from the email here.</p>

								<?php if (count($errors) > 0): ?>
									<div class="alert alert-danger">
										<?php foreach ($errors as $error): ?>
											<?= htmlspecialchars($error) ?> <br>
										<?php endforeach; ?>
									</div>
								<?php endif; ?>

								<form method="post">
									<div class="form-outline form-white mb-4">
										<input type="text" class="form-control form-control-lg" name="code" placeholder="Enter your Code" required>
									</div>
									<button type="submit" class="btn btn-outline-light btn-lg px-5">Verify</button>
								</form>
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Bootstrap JS and jQuery -->
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
